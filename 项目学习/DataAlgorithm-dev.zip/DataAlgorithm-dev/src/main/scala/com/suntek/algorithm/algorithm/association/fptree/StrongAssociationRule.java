package com.suntek.algorithm.algorithm.association.fptree;

import java.util.List;

/**
 * @author zhy
 * @date 2020-9-10 12:00
 */
public class StrongAssociationRule {
    public List<String> condition;
    public String result;
    public int support;
    public double confidence;
}
